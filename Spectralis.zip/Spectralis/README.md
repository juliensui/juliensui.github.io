# Spectralis - Granular Synthesizer & Spectrum Analyzer

S4 EPITA Project - By Oren, Julien, Florent and Tao.

Spectralis is a granular synthesizer coupled with a real-time FFT spectrum analyzer, built in Rust. It can process audio files (WAV, MP3, FLAC) or live microphone input.

## Prerequisites
- **Rust** and **Cargo** must be installed.
- On Linux, standard audio dependencies may be required (e.g. `libasound2-dev` for ALSA).

## Build and Run

To build the project with optimizations (recommended for audio performance):
```bash
cargo build --release

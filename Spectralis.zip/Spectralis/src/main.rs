mod fft;
mod grain_engine;
mod gui;

use crate::fft::{apply_hann_window, compute_magnitudes_db, fft, samples_to_complex};
use crate::grain_engine::{CircularBuffer, GrainCloud};
use crate::gui::{GuiApp, SpectrumFrame};

use cpal::traits::{DeviceTrait, HostTrait, StreamTrait};
use eframe::egui::IconData;
use ringbuf::{HeapRb, traits::*};
use std::sync::{
    Arc, Mutex,
    atomic::{AtomicBool, AtomicU32, AtomicUsize, Ordering},
};
use std::time::Duration;

fn load_icon(path: &str) -> IconData {
    let base_path = std::path::PathBuf::from(env!("CARGO_MANIFEST_DIR"));
    let full_path = base_path.join(path);

    let image = image::open(&full_path)
        .unwrap_or_else(|_| panic!("Failed to open logo at path: {:?}", full_path))
        .into_rgba8();

    let (width, height) = image.dimensions();
    let rgba = image.into_raw();

    IconData {
        rgba,
        width,
        height,
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum AudioSourceMode {
    Micro = 0,
    File = 1,
}

fn lerp(a: f32, b: f32, t: f32) -> f32 {
    a + (b - a) * t
}

fn resample_vec_linear(input: &[f32], in_rate: f32, out_rate: f32) -> Vec<f32> {
    if input.is_empty() {
        return Vec::new();
    }

    if (in_rate - out_rate).abs() < f32::EPSILON {
        return input.to_vec();
    }

    let out_len = ((input.len() as f32) * out_rate / in_rate).round() as usize;
    let mut out = Vec::with_capacity(out_len.max(1));

    for n in 0..out_len.max(1) {
        let src_pos = (n as f32) * in_rate / out_rate;
        let i0 = src_pos.floor() as usize;
        let i1 = (i0 + 1).min(input.len() - 1);
        let frac = src_pos - i0 as f32;
        out.push(lerp(input[i0], input[i1], frac));
    }

    out
}

fn load_wav_mono(path: &str) -> Result<(Vec<f32>, u32), String> {
    let mut reader = hound::WavReader::open(path)
        .map_err(|e| format!("Failed to open {}: {:?}", path, e))?;

    let spec = reader.spec();
    let sample_rate = spec.sample_rate;
    let channels = spec.channels as usize;

    let interleaved: Vec<f32> = match spec.sample_format {
        hound::SampleFormat::Float => reader
            .samples::<f32>()
            .map(|s| s.map_err(|e| format!("Error reading float sample: {:?}", e)))
            .collect::<Result<Vec<_>, _>>()?,
        hound::SampleFormat::Int => {
            if spec.bits_per_sample <= 16 {
                reader
                    .samples::<i16>()
                    .map(|s| {
                        s.map(|v| v as f32 / i16::MAX as f32)
                            .map_err(|e| format!("Error reading i16 sample: {:?}", e))
                    })
                    .collect::<Result<Vec<_>, _>>()?
            } else {
                reader
                    .samples::<i32>()
                    .map(|s| {
                        s.map(|v| v as f32 / i32::MAX as f32)
                            .map_err(|e| format!("Error reading i32 sample: {:?}", e))
                    })
                    .collect::<Result<Vec<_>, _>>()?
            }
        }
    };

    let mono = if channels <= 1 {
        interleaved
    } else {
        interleaved
            .chunks(channels)
            .map(|frame| frame.iter().copied().sum::<f32>() / channels as f32)
            .collect()
    };

    Ok((mono, sample_rate))
}

/// Load an audio file (MP3 or FLAC) via symphonia. Returns mono samples + sample rate.
fn load_symphonia_mono(path: &str) -> Result<(Vec<f32>, u32), String> {
    use symphonia::core::audio::SampleBuffer;
    use symphonia::core::codecs::DecoderOptions;
    use symphonia::core::formats::FormatOptions;
    use symphonia::core::io::MediaSourceStream;
    use symphonia::core::meta::MetadataOptions;
    use symphonia::core::probe::Hint;

    let file =
        std::fs::File::open(path).map_err(|e| format!("Failed to open {}: {:?}", path, e))?;

    let mss = MediaSourceStream::new(Box::new(file), Default::default());

    let mut hint = Hint::new();
    if let Some(ext) = std::path::Path::new(path)
        .extension()
        .and_then(|e| e.to_str())
    {
        hint.with_extension(ext);
    }

    let probed = symphonia::default::get_probe()
        .format(
            &hint,
            mss,
            &FormatOptions::default(),
            &MetadataOptions::default(),
        )
        .map_err(|e| format!("Unrecognized format for {}: {:?}", path, e))?;

    let mut format = probed.format;

    let track = format
        .default_track()
        .ok_or_else(|| "No audio track found.".to_string())?;

    let track_id = track.id;
    let sample_rate = track
        .codec_params
        .sample_rate
        .ok_or_else(|| "Unknown sample rate.".to_string())?;
    let channels = track.codec_params.channels.map(|c| c.count()).unwrap_or(1);

    let mut decoder = symphonia::default::get_codecs()
        .make(&track.codec_params, &DecoderOptions::default())
        .map_err(|e| format!("Failed to create decoder: {:?}", e))?;

    let mut all_samples: Vec<f32> = Vec::new();

    loop {
        let packet = match format.next_packet() {
            Ok(p) => p,
            Err(symphonia::core::errors::Error::IoError(ref e))
                if e.kind() == std::io::ErrorKind::UnexpectedEof =>
            {
                break;
            }
            Err(e) => return Err(format!("Error reading packet: {:?}", e)),
        };

        if packet.track_id() != track_id {
            continue;
        }

        let decoded = decoder
            .decode(&packet)
            .map_err(|e| format!("Decoding error: {:?}", e))?;

        let spec = *decoded.spec();
        let num_frames = decoded.capacity();

        let mut sample_buf = SampleBuffer::<f32>::new(num_frames as u64, spec);
        sample_buf.copy_interleaved_ref(decoded);

        let interleaved = sample_buf.samples();

        if channels <= 1 {
            all_samples.extend_from_slice(interleaved);
        } else {
            for frame in interleaved.chunks(channels) {
                let mono = frame.iter().copied().sum::<f32>() / channels as f32;
                all_samples.push(mono);
            }
        }
    }

    if all_samples.is_empty() {
        return Err("Audio file is empty or could not be decoded.".to_string());
    }

    Ok((all_samples, sample_rate))
}

/// Load a mono audio file (WAV, MP3 or FLAC), detecting format by extension.
fn load_audio_mono(path: &str) -> Result<(Vec<f32>, u32), String> {
    let ext = std::path::Path::new(path)
        .extension()
        .and_then(|e| e.to_str())
        .map(|e| e.to_lowercase())
        .unwrap_or_default();

    match ext.as_str() {
        "wav" => load_wav_mono(path),
        "mp3" | "flac" => load_symphonia_mono(path),
        _ => Err(format!(
            "Unsupported audio format: '.{}'. Supported: .wav, .mp3, .flac",
            ext
        )),
    }
}

/// Process samples with the current granular parameters in a single pass
/// and save the result to a WAV file.
pub fn save_wav_offline(
    samples: &[f32],
    sample_rate: u32,
    pitch: f32,
    density: f32,
    grain_size_ms: f32,
    effect_on: bool,
    file_name: &str,
) -> Result<(), String> {
    if samples.is_empty() {
        return Err("No samples to save.".to_string());
    }

    let mut buffer = CircularBuffer::new(sample_rate as usize);
    let mut cloud = GrainCloud::new(441, sample_rate as f32);
    cloud.set_pitch(pitch);
    cloud.set_density(density);
    cloud.set_grain_size(grain_size_ms);
    cloud.set_mix(if effect_on { 1.0 } else { 0.0 });

    let mut output: Vec<f32> = Vec::with_capacity(samples.len());
    for &sample in samples.iter() {
        buffer.add_sample(sample);
        let out = if effect_on {
            cloud.process(&buffer)
        } else {
            sample
        };
        output.push(out);
    }

    let path_str = if file_name.to_lowercase().ends_with(".wav") {
        file_name.to_string()
    } else {
        format!("{}.wav", file_name)
    };

    let spec = hound::WavSpec {
        channels: 1,
        sample_rate,
        bits_per_sample: 32,
        sample_format: hound::SampleFormat::Float,
    };

    let mut writer = hound::WavWriter::create(&path_str, spec)
        .map_err(|e| format!("Failed to create '{}': {:?}", path_str, e))?;

    for s in &output {
        writer
            .write_sample(*s)
            .map_err(|e| format!("Error writing sample: {:?}", e))?;
    }

    writer
        .finalize()
        .map_err(|e| format!("Error finalizing WAV: {:?}", e))?;

    println!("WAV saved: {}", path_str);
    Ok(())
}

fn run_audio(
    pitch_partage: Arc<AtomicU32>,
    density_partage: Arc<AtomicU32>,
    size_partage: Arc<AtomicU32>,
    effect_on_partage: Arc<AtomicU32>,
    source_mode_partage: Arc<AtomicU32>,
    load_trigger: Arc<AtomicU32>,
    shared_file_path: Arc<Mutex<String>>,
    loaded_file_samples: Arc<Mutex<Vec<f32>>>,
    loaded_file_index: Arc<AtomicUsize>,
    audio_running: Arc<AtomicBool>,
    recording_flag: Arc<AtomicBool>,
    recorded_samples: Arc<Mutex<Vec<f32>>>,
    playback_flag: Arc<AtomicBool>,
    playback_index: Arc<AtomicUsize>,
    shared_input_sample_rate: Arc<AtomicU32>,
    shared_output_sample_rate: Arc<AtomicU32>,
    shared_playback_resampled: Arc<Mutex<Vec<f32>>>,
    shared_spectrum: Arc<Mutex<Option<SpectrumFrame>>>,
    reverse_partage: Arc<AtomicU32>,
) {
    let host = cpal::default_host();

    let input_device = host
        .default_input_device()
        .expect("No input device found");

    let output_device = host
        .default_output_device()
        .expect("No output device found");

    println!("Input device: {}", input_device.description().unwrap());
    println!("Output device: {}", output_device.description().unwrap());

    let input_config = input_device.default_input_config().unwrap();
    let output_config = output_device.default_output_config().unwrap();

    println!("Input config: {:?}", input_config);
    println!("Output config: {:?}", output_config);

    let input_sample_rate = input_config.sample_rate() as f32;
    let output_sample_rate = output_config.sample_rate() as f32;

    shared_input_sample_rate.store(input_sample_rate.to_bits(), Ordering::Relaxed);
    shared_output_sample_rate.store(output_sample_rate.to_bits(), Ordering::Relaxed);

    let output_channels = output_config.channels() as usize;
    let input_channels = input_config.channels() as usize;

    let mut buffer = CircularBuffer::new(output_sample_rate as usize);
    let mut cloud = GrainCloud::new(441, output_sample_rate);

    let rb = HeapRb::<f32>::new(96000);
    let (mut producer, mut consumer) = rb.split();

    let input_stream_config: cpal::StreamConfig = input_config.clone().into();
    let output_stream_config: cpal::StreamConfig = output_config.clone().into();

    let rec_flag_input = recording_flag.clone();
    let recorded_input = recorded_samples.clone();

    let input_stream = match input_config.sample_format() {
        cpal::SampleFormat::F32 => input_device
            .build_input_stream(
                &input_stream_config,
                move |data: &[f32], _: &cpal::InputCallbackInfo| {
                    for frame in data.chunks(input_channels) {
                        let mono = frame.iter().copied().sum::<f32>() / input_channels as f32;
                        let _ = producer.try_push(mono);

                        if rec_flag_input.load(Ordering::Relaxed) {
                            if let Ok(mut vec) = recorded_input.lock() {
                                vec.push(mono);
                            }
                        }
                    }
                },
                move |err| eprintln!("Audio input error: {:?}", err),
                None,
            )
            .unwrap(),
        _ => panic!("Unsupported input format"),
    };

    let live_step = input_sample_rate / output_sample_rate;
    let mut live_src_pos = 0.0f32;
    let mut live_s0 = consumer.try_pop().unwrap_or(0.0);
    let mut live_s1 = consumer.try_pop().unwrap_or(live_s0);

    let playback_resampled_out = shared_playback_resampled.clone();
    let recorded_samples_out = recorded_samples.clone();

    let mut last_load_trigger = load_trigger.load(Ordering::Relaxed);
    let fft_size = 1024usize;
    let mut fft_input_buffer: Vec<f32> = Vec::with_capacity(fft_size);

    let output_stream = match output_config.sample_format() {
        cpal::SampleFormat::F32 => output_device
            .build_output_stream(
                &output_stream_config,
                move |data: &mut [f32], _: &cpal::OutputCallbackInfo| {
                    let current_load_trigger = load_trigger.load(Ordering::Relaxed);
                    if current_load_trigger != last_load_trigger {
                        last_load_trigger = current_load_trigger;

                        let wav_path_str = {
                            let lock = shared_file_path.lock().unwrap();
                            lock.clone()
                        };
                        if !wav_path_str.is_empty() {
                            println!("Loading audio file: {}", wav_path_str);

                            match load_audio_mono(&wav_path_str) {
                                Ok((samples, file_sr)) => {
                                    let converted = resample_vec_linear(
                                        &samples,
                                        file_sr as f32,
                                        output_sample_rate,
                                    );
                                    if let Ok(mut dst) = loaded_file_samples.lock() {
                                        *dst = converted;
                                    }
                                    loaded_file_index.store(0, Ordering::Relaxed);
                                    println!("File loaded successfully! ({} Hz)", file_sr);
                                }
                                Err(e) => {
                                    eprintln!("File loading error: {}", e);
                                }
                            }
                        } else {
                            println!("No file selected.");
                        }
                    }
                    for frame in data.chunks_mut(output_channels) {
                        if !audio_running.load(Ordering::Relaxed) {
                            for s in frame.iter_mut() {
                                *s = 0.0;
                            }
                            continue;
                        }

                        let slider_pitch = f32::from_bits(pitch_partage.load(Ordering::Relaxed));
                        cloud.set_pitch(slider_pitch);

                        let slider_density =
                            f32::from_bits(density_partage.load(Ordering::Relaxed));
                        cloud.set_density(slider_density);

                        let slider_size = f32::from_bits(size_partage.load(Ordering::Relaxed));
                        cloud.set_grain_size(slider_size);

                        let slider_reverse =
                            f32::from_bits(reverse_partage.load(Ordering::Relaxed));
                        cloud.set_reverse_prob(slider_reverse);

                        let effect_on =
                            f32::from_bits(effect_on_partage.load(Ordering::Relaxed)) > 0.5;
                        cloud.set_mix(if effect_on { 1.0 } else { 0.0 });

                        let source_mode = source_mode_partage.load(Ordering::Relaxed);

                        let out = if playback_flag.load(Ordering::Relaxed) {
                            let mut need_prepare = false;

                            if playback_index.load(Ordering::Relaxed) == 0 {
                                if let Ok(buf) = playback_resampled_out.lock() {
                                    if buf.is_empty() {
                                        need_prepare = true;
                                    }
                                }
                            }

                            if need_prepare {
                                if let Ok(src) = recorded_samples_out.lock() {
                                    let converted = resample_vec_linear(
                                        &src,
                                        input_sample_rate,
                                        output_sample_rate,
                                    );
                                    if let Ok(mut dst) = playback_resampled_out.lock() {
                                        *dst = converted;
                                    }
                                }
                            }

                            if let Ok(buf) = playback_resampled_out.lock() {
                                let i = playback_index.load(Ordering::Relaxed);

                                if i < buf.len() {
                                    let sample = buf[i];
                                    playback_index.store(i + 1, Ordering::Relaxed);

                                    buffer.add_sample(sample);

                                    if effect_on {
                                        cloud.process(&buffer)
                                    } else {
                                        sample
                                    }
                                } else {
                                    playback_index.store(0, Ordering::Relaxed);
                                    0.0
                                }
                            } else {
                                0.0
                            }
                        } else if source_mode == AudioSourceMode::File as u32 {
                            if let Ok(buf) = loaded_file_samples.lock() {
                                let i = loaded_file_index.load(Ordering::Relaxed);

                                if i < buf.len() {
                                    let sample = buf[i];
                                    loaded_file_index.store(i + 1, Ordering::Relaxed);

                                    buffer.add_sample(sample);

                                    if effect_on {
                                        cloud.process(&buffer)
                                    } else {
                                        sample
                                    }
                                } else {
                                    loaded_file_index.store(0, Ordering::Relaxed);
                                    0.0
                                }
                            } else {
                                0.0
                            }
                        } else {
                            while live_src_pos >= 1.0 {
                                live_src_pos -= 1.0;
                                live_s0 = live_s1;
                                live_s1 = consumer.try_pop().unwrap_or(live_s0);
                            }

                            let live_sample = lerp(live_s0, live_s1, live_src_pos);
                            live_src_pos += live_step;

                            if recording_flag.load(Ordering::Relaxed) {
                                buffer.add_sample(live_sample);
                            }

                            0.0
                        };
                        fft_input_buffer.push(out);

                        if fft_input_buffer.len() >= fft_size {
                            let mut complex = samples_to_complex(&fft_input_buffer);
                            apply_hann_window(&mut complex);
                            fft(&mut complex);

                            let magnitudes = compute_magnitudes_db(&complex);

                            if let Ok(mut shared) = shared_spectrum.lock() {
                                *shared = Some(SpectrumFrame {
                                    magnitudes,
                                    sample_rate: output_sample_rate as u32,
                                });
                            }

                            fft_input_buffer.clear();
                        }
                        for s in frame.iter_mut() {
                            *s = out;
                        }
                    }
                },
                move |err| eprintln!("Audio error: {:?}", err),
                None,
            )
            .unwrap(),
        _ => panic!("Unsupported audio format"),
    };

    input_stream.play().unwrap();
    output_stream.play().unwrap();
    println!("Audio + granular engine running...");

    loop {
        std::thread::sleep(Duration::from_secs(1));
    }
}

fn main() -> eframe::Result<()> {
    let pitch_partage = Arc::new(AtomicU32::new(1.0f32.to_bits()));
    let density_partage = Arc::new(AtomicU32::new(20.0f32.to_bits()));
    let size_partage = Arc::new(AtomicU32::new(50.0f32.to_bits()));
    let effect_on_partage = Arc::new(AtomicU32::new(0.0f32.to_bits()));
    let reverse_partage = Arc::new(AtomicU32::new(0.0f32.to_bits()));

    let source_mode_partage = Arc::new(AtomicU32::new(AudioSourceMode::Micro as u32));
    let load_trigger = Arc::new(AtomicU32::new(0));

    let shared_file_path = Arc::new(Mutex::new(String::new()));

    let loaded_file_samples = Arc::new(Mutex::new(Vec::<f32>::new()));
    let loaded_file_index = Arc::new(AtomicUsize::new(0));

    let audio_running = Arc::new(AtomicBool::new(true));

    let recording_flag = Arc::new(AtomicBool::new(false));
    let recorded_samples = Arc::new(Mutex::new(Vec::<f32>::new()));

    let playback_flag = Arc::new(AtomicBool::new(false));
    let playback_index = Arc::new(AtomicUsize::new(0));


    let shared_input_sample_rate = Arc::new(AtomicU32::new(44100f32.to_bits()));
    let shared_output_sample_rate = Arc::new(AtomicU32::new(44100f32.to_bits()));
    let shared_playback_resampled = Arc::new(Mutex::new(Vec::<f32>::new()));
    let shared_spectrum = Arc::new(Mutex::new(None::<SpectrumFrame>));

    let p_audio = pitch_partage.clone();
    let d_audio = density_partage.clone();
    let s_audio = size_partage.clone();
    let e_audio = effect_on_partage.clone();

    let src_audio = source_mode_partage.clone();
    let load_audio = load_trigger.clone();
    let path_audio = shared_file_path.clone();
    let file_audio = loaded_file_samples.clone();
    let file_index_audio = loaded_file_index.clone();

    let running_audio = audio_running.clone();

    let rec_audio = recording_flag.clone();
    let samples_audio = recorded_samples.clone();
    let r_audio = reverse_partage.clone();

    let play_audio = playback_flag.clone();
    let index_audio = playback_index.clone();
    let in_sr_audio = shared_input_sample_rate.clone();
    let out_sr_audio = shared_output_sample_rate.clone();
    let pb_resampled_audio = shared_playback_resampled.clone();
    let r_gui = reverse_partage.clone();
    let spectrum_audio = shared_spectrum.clone();

    std::thread::spawn(move || {
        run_audio(
            p_audio,
            d_audio,
            s_audio,
            e_audio,
            src_audio,
            load_audio,
            path_audio,
            file_audio,
            file_index_audio,
            running_audio,
            rec_audio,
            samples_audio,
            play_audio,
            index_audio,
            in_sr_audio,
            out_sr_audio,
            pb_resampled_audio,
            spectrum_audio,
            r_audio,
        );
    });

    let p_gui = pitch_partage.clone();
    let d_gui = density_partage.clone();
    let s_gui = size_partage.clone();
    let e_gui = effect_on_partage.clone();

    let src_gui = source_mode_partage.clone();
    let load_gui = load_trigger.clone();
    let path_gui = shared_file_path.clone();
    let file_gui = loaded_file_samples.clone();

    let running_gui = audio_running.clone();

    let rec_gui = recording_flag.clone();
    let samples_gui = recorded_samples.clone();
    let play_gui = playback_flag.clone();
    let index_gui = playback_index.clone();
    let in_sr_gui = shared_input_sample_rate.clone();
    let out_sr_gui = shared_output_sample_rate.clone();
    let pb_resampled_gui = shared_playback_resampled.clone();
    let spectrum_gui = shared_spectrum.clone();

    let icon = load_icon("assets/logo.png");

    let options = eframe::NativeOptions {
        renderer: eframe::Renderer::Glow,
        viewport: eframe::egui::ViewportBuilder::default()
            .with_inner_size(eframe::egui::vec2(900.0, 600.0))
            .with_icon(std::sync::Arc::new(icon)),
        ..Default::default()
    };

    eframe::run_native(
        "Audio Spectrum Analyzer & Granular Synth",
        options,
        Box::new(move |_cc| {
            Ok(Box::new(GuiApp::new(
                p_gui,
                d_gui,
                s_gui,
                e_gui,
                src_gui,
                load_gui,
                path_gui,
                file_gui,
                running_gui,
                rec_gui,
                play_gui,
                index_gui,
                samples_gui,
                in_sr_gui,
                pb_resampled_gui,
                out_sr_gui,
                spectrum_gui,
                r_gui,
            )) as Box<dyn eframe::App>)
        }),
    )
}

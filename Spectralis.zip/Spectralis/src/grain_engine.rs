use std::f32::consts::PI;

// sound sample
pub struct Grain {
    start_index: usize,
    duration: f64,
    current_pos: f32,
    amplitude: f32,
    pub pitch_ratio: f32,
    pub is_reversed: bool,
}

impl Grain {
    pub fn get_next_sample(&mut self, buffer: &CircularBuffer) -> f32 {
        let pos_in_grain = if self.is_reversed {
            (self.duration as f32 - self.current_pos).max(0.0)
        } else {
            self.current_pos
        };

        let index_a_lire = self.start_index + (pos_in_grain as usize);
        let sample = buffer.get_sample(index_a_lire);

        let n = self.current_pos;
        let n_total = self.duration as f32;
        let hanning_multiplier = 0.5 * (1.0 - (2.0 * PI * n / n_total).cos());
        self.current_pos += self.pitch_ratio;
        sample * hanning_multiplier * self.amplitude
    }
}

// sound buffer
pub struct CircularBuffer {
    buffer: Vec<f32>,
    write_ptr: usize,
    pub size: usize,
}

impl CircularBuffer {
    pub fn new(taille_voulu: usize) -> Self {
        Self {
            buffer: vec![0.0; taille_voulu],
            write_ptr: 0,
            size: taille_voulu,
        }
    }

    pub fn add_sample(&mut self, echantillon: f32) {
        self.buffer[self.write_ptr] = echantillon;
        self.write_ptr += 1;
        if self.write_ptr == self.size {
            self.write_ptr = 0;
        }
    }

    pub fn get_sample(&self, index: usize) -> f32 {
        let index_secu = index % self.size;
        self.buffer[index_secu]
    }

    pub fn get_past_sample(&self, decalage: usize) -> f32 {
        let index_lecture = (self.write_ptr + self.size - decalage) % self.size;
        self.get_sample(index_lecture)
    }

    pub fn get_write_ptr(&self) -> usize {
        self.write_ptr
    }
}

pub struct GrainCloud {
    grains: Vec<Grain>,
    spawn_interval: usize,
    sample_since_last_spawn: usize,
    pub current_pitch: f32,
    pub current_grain_size: f64,
    pub mix: f32,
    pub sample_rate: f32,
    pub reverse_prob: f32,
}

impl GrainCloud {
    pub fn new(intervale_voulu: usize, sample_rate: f32) -> Self {
        Self {
            grains: Vec::new(),
            spawn_interval: intervale_voulu,
            sample_since_last_spawn: 0,
            current_pitch: 1.0,
            current_grain_size: sample_rate as f64 * 0.050,
            mix: 0.0,
            sample_rate,
            reverse_prob: 0.0,
        }
    }

    pub fn set_pitch(&mut self, pitch: f32) {
        self.current_pitch = pitch;
    }

    pub fn set_density(&mut self, grains_per_second: f32) {
        let safe_gps = grains_per_second.max(0.1);
        self.spawn_interval = (self.sample_rate / safe_gps) as usize;
    }

    pub fn set_grain_size(&mut self, size_ms: f32) {
        self.current_grain_size = (size_ms * self.sample_rate / 1000.0) as f64;
    }
    pub fn set_reverse_prob(&mut self, prob: f32) {
        self.reverse_prob = prob.clamp(0.0, 1.0);
    }

    pub fn set_mix(&mut self, mix: f32) {
        self.mix = mix.clamp(0.0, 1.0);
    }

    pub fn process(&mut self, buffer: &CircularBuffer) -> f32 {
        let dry = buffer.get_past_sample(1);

        self.sample_since_last_spawn += 1;
        if self.sample_since_last_spawn > self.spawn_interval {
            let max_delay = (self.sample_rate as usize / 9).max(1000);
            let min_delay = (self.sample_rate as usize / 16).max(500);
            let decalage_aleatoire = (rand::random::<u32>() as usize % max_delay) + min_delay;

            let duree = self.current_grain_size;
            let is_rev = rand::random::<f32>() < self.reverse_prob;
            let g = Grain {
                start_index: (buffer.get_write_ptr() + buffer.size - decalage_aleatoire)
                    % buffer.size,
                duration: duree,
                current_pos: 0.0,
                amplitude: 0.5,
                pitch_ratio: self.current_pitch,
                is_reversed: is_rev,
            };
            self.grains.push(g);
            self.sample_since_last_spawn = 0;
        }

        let mut wet = 0.0;
        for g in self.grains.iter_mut() {
            wet += g.get_next_sample(buffer);
        }

        self.grains.retain(|g| (g.current_pos as f64) < g.duration);
        wet = wet.tanh();

        dry * (1.0 - self.mix) + wet * self.mix
    }
}

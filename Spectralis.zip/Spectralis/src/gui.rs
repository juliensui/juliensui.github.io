use eframe::egui;
use egui_plot::{Line, Plot, PlotPoints};
use std::sync::{
    Arc, Mutex,
    atomic::{AtomicBool, AtomicU32, AtomicUsize, Ordering},
};

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum AudioSourceMode {
    Micro = 0,
    File = 1,
}

#[derive(Clone, Copy, Debug)]
pub struct GranularParams {
    pub grain_size_ms: f32,
    pub density: f32,
    pub pitch: f32,
    pub reverse_prob: f32,
    pub effect_on: bool,
    pub source_mode: AudioSourceMode,
}

impl Default for GranularParams {
    fn default() -> Self {
        Self {
            grain_size_ms: 50.0,
            density: 20.0,
            pitch: 1.0,
            reverse_prob: 0.0,
            effect_on: false,
            source_mode: AudioSourceMode::Micro,
        }
    }
}

#[derive(Clone, Debug)]
pub struct SpectrumFrame {
    pub magnitudes: Vec<f32>,
    pub sample_rate: u32,
}

pub struct GuiApp {
    pub params: GranularParams,
    pub spectrum: Option<SpectrumFrame>,
    pub shared_spectrum: Arc<Mutex<Option<SpectrumFrame>>>,
    pub shared_pitch: Arc<AtomicU32>,
    pub shared_density: Arc<AtomicU32>,
    pub shared_size: Arc<AtomicU32>,
    pub shared_effect_on: Arc<AtomicU32>,
    pub shared_source_mode: Arc<AtomicU32>,
    pub load_trigger: Arc<AtomicU32>,
    pub shared_file_path: Arc<Mutex<String>>,
    pub loaded_file_samples: Arc<Mutex<Vec<f32>>>,
    pub audio_running: Arc<AtomicBool>,
    pub recording_flag: Arc<AtomicBool>,
    pub playback_flag: Arc<AtomicBool>,
    pub playback_index: Arc<AtomicUsize>,
    pub recorded_samples: Arc<Mutex<Vec<f32>>>,
    pub show_help: bool,
    pub shared_reverse: Arc<AtomicU32>,

    // Real input sample rate (set by the audio thread)
    pub shared_input_sample_rate: Arc<AtomicU32>,
    // Shared playback buffer (cleared on Clear Rec)
    pub shared_playback_resampled: Arc<Mutex<Vec<f32>>>,
    // Real output sample rate (for correct WAV export)
    pub shared_output_sample_rate: Arc<AtomicU32>,

    // --- Save dialog state ---
    pub save_status_msg: Option<(String, bool)>, // (message, is_error)
}

impl GuiApp {
    pub fn new(
        shared_pitch: Arc<AtomicU32>,
        shared_density: Arc<AtomicU32>,
        shared_size: Arc<AtomicU32>,
        shared_effect_on: Arc<AtomicU32>,
        shared_source_mode: Arc<AtomicU32>,
        load_trigger: Arc<AtomicU32>,
        shared_file_path: Arc<Mutex<String>>,
        loaded_file_samples: Arc<Mutex<Vec<f32>>>,
        audio_running: Arc<AtomicBool>,
        recording_flag: Arc<AtomicBool>,
        playback_flag: Arc<AtomicBool>,
        playback_index: Arc<AtomicUsize>,
        recorded_samples: Arc<Mutex<Vec<f32>>>,
        shared_input_sample_rate: Arc<AtomicU32>,
        shared_playback_resampled: Arc<Mutex<Vec<f32>>>,
        shared_output_sample_rate: Arc<AtomicU32>,
        shared_spectrum: Arc<Mutex<Option<SpectrumFrame>>>,
        shared_reverse: Arc<AtomicU32>,
    ) -> Self {
        Self {
            params: GranularParams::default(),
            spectrum: None,
            shared_spectrum,
            shared_pitch,
            shared_density,
            shared_size,
            shared_effect_on,
            shared_source_mode,
            load_trigger,
            shared_file_path,
            loaded_file_samples,
            audio_running,
            recording_flag,
            playback_flag,
            playback_index,
            recorded_samples,
            shared_input_sample_rate,
            shared_playback_resampled,
            shared_output_sample_rate,
            save_status_msg: None,
            show_help: false,
            shared_reverse,
        }
    }

    fn apply_theme(ctx: &egui::Context) {
        let mut style = (*ctx.style()).clone();

        style.visuals = egui::Visuals::dark();
        style.visuals.window_fill = egui::Color32::from_rgb(18, 22, 28);
        style.visuals.panel_fill = egui::Color32::from_rgb(18, 22, 28);
        style.visuals.faint_bg_color = egui::Color32::from_rgb(30, 36, 45);
        style.visuals.extreme_bg_color = egui::Color32::from_rgb(12, 15, 20);
        style.visuals.code_bg_color = egui::Color32::from_rgb(25, 30, 38);

        style.visuals.widgets.noninteractive.bg_fill = egui::Color32::from_rgb(26, 31, 40);
        style.visuals.widgets.inactive.bg_fill = egui::Color32::from_rgb(36, 42, 54);
        style.visuals.widgets.hovered.bg_fill = egui::Color32::from_rgb(52, 60, 76);
        style.visuals.widgets.active.bg_fill = egui::Color32::from_rgb(70, 90, 120);
        style.visuals.widgets.inactive.fg_stroke.color = egui::Color32::from_rgb(230, 235, 240);
        style.visuals.widgets.hovered.fg_stroke.color = egui::Color32::WHITE;
        style.visuals.widgets.active.fg_stroke.color = egui::Color32::WHITE;
        style.visuals.window_stroke.color = egui::Color32::from_rgb(60, 70, 85);
        style.visuals.widgets.noninteractive.bg_stroke.color = egui::Color32::from_rgb(50, 60, 75);

        style.spacing.item_spacing = egui::vec2(10.0, 10.0);
        style.spacing.button_padding = egui::vec2(14.0, 10.0);
        style.spacing.slider_width = 180.0;

        style.visuals.widgets.inactive.corner_radius = egui::CornerRadius::same(10);
        style.visuals.widgets.hovered.corner_radius = egui::CornerRadius::same(10);
        style.visuals.widgets.active.corner_radius = egui::CornerRadius::same(10);
        style.visuals.menu_corner_radius = egui::CornerRadius::same(12);
        style.visuals.window_corner_radius = egui::CornerRadius::same(14);

        ctx.set_style(style);
    }

    fn premium_button(
        ui: &mut egui::Ui,
        text: &str,
        fill: egui::Color32,
        min_size: [f32; 2],
    ) -> egui::Response {
        let stroke = egui::Stroke::new(1.0, fill.gamma_multiply(0.55));
        let highlight = fill.gamma_multiply(1.15);

        let button = egui::Button::new(
            egui::RichText::new(text)
                .size(14.5)
                .strong()
                .color(egui::Color32::from_rgb(245, 247, 250)),
        )
        .min_size(egui::vec2(min_size[0], min_size[1]))
        .fill(fill)
        .stroke(stroke)
        .corner_radius(egui::CornerRadius::same(14));

        let response = ui.add(button);

        if ui.is_rect_visible(response.rect) {
            let rect = response.rect;
            let painter = ui.painter();

            let top_glow = egui::Rect::from_min_max(
                rect.min + egui::vec2(1.0, 1.0),
                egui::pos2(rect.max.x - 1.0, rect.min.y + rect.height() * 0.45),
            );

            painter.rect_stroke(
                rect.shrink(0.5),
                egui::CornerRadius::same(14),
                egui::Stroke::new(
                    1.0,
                    if response.hovered() {
                        highlight
                    } else {
                        fill.gamma_multiply(0.7)
                    },
                ),
                egui::StrokeKind::Outside,
            );

            painter.rect_filled(
                top_glow,
                egui::CornerRadius::same(13),
                egui::Color32::from_white_alpha(if response.hovered() { 24 } else { 14 }),
            );
        }

        response
    }

    fn premium_toggle_button(
        ui: &mut egui::Ui,
        text: &str,
        selected: bool,
        min_size: [f32; 2],
    ) -> egui::Response {
        let fill = if selected {
            egui::Color32::from_rgb(78, 126, 230)
        } else {
            egui::Color32::from_rgb(42, 48, 60)
        };

        let text_color = if selected {
            egui::Color32::WHITE
        } else {
            egui::Color32::from_rgb(210, 218, 228)
        };

        let stroke = if selected {
            egui::Stroke::new(1.2, egui::Color32::from_rgb(120, 160, 255))
        } else {
            egui::Stroke::new(1.0, egui::Color32::from_rgb(68, 76, 92))
        };

        ui.add(
            egui::Button::new(
                egui::RichText::new(text)
                    .size(14.0)
                    .strong()
                    .color(text_color),
            )
            .min_size(egui::vec2(min_size[0], min_size[1]))
            .fill(fill)
            .stroke(stroke)
            .corner_radius(egui::CornerRadius::same(12)),
        )
    }

    fn section_card<R>(
        ui: &mut egui::Ui,
        title: &str,
        add_content: impl FnOnce(&mut egui::Ui) -> R,
    ) -> R {
        egui::Frame::new()
            .fill(egui::Color32::from_rgb(28, 33, 42))
            .stroke(egui::Stroke::new(1.0, egui::Color32::from_rgb(55, 65, 80)))
            .corner_radius(egui::CornerRadius::same(14))
            .inner_margin(egui::Margin::same(14))
            .show(ui, |ui| {
                ui.label(
                    egui::RichText::new(title)
                        .size(18.0)
                        .strong()
                        .color(egui::Color32::from_rgb(240, 244, 248)),
                );

                ui.add_space(8.0);

                add_content(ui)
            })
            .inner
    }

    /// Open the native file dialog and save as WAV.
    fn trigger_save(&mut self) {
        let samples = match self.params.source_mode {
            AudioSourceMode::File => match self.loaded_file_samples.lock() {
                Ok(s) if !s.is_empty() => s.clone(),
                _ => {
                    self.save_status_msg = Some(("⚠ No file loaded.".to_string(), true));
                    return;
                }
            },
            AudioSourceMode::Micro => match self.recorded_samples.lock() {
                Ok(s) if !s.is_empty() => s.clone(),
                _ => {
                    self.save_status_msg = Some(("⚠ No recorded audio.".to_string(), true));
                    return;
                }
            },
        };

        if let Some(path) = rfd::FileDialog::new()
            .add_filter("Audio File", &["wav"])
            .set_file_name("granular_output.wav")
            .save_file()
        {
            let sample_rate: u32 = match self.params.source_mode {
                AudioSourceMode::Micro => {
                    f32::from_bits(self.shared_input_sample_rate.load(Ordering::Relaxed)) as u32
                }
                AudioSourceMode::File => {
                    f32::from_bits(self.shared_output_sample_rate.load(Ordering::Relaxed)) as u32
                }
            };

            let file_path_str = path.display().to_string();

            match crate::save_wav_offline(
                &samples,
                sample_rate,
                self.params.pitch,
                self.params.density,
                self.params.grain_size_ms,
                self.params.effect_on,
                &file_path_str,
            ) {
                Ok(()) => {
                    self.save_status_msg =
                        Some(("✅ File saved successfully!".to_string(), false));
                }
                Err(e) => {
                    self.save_status_msg = Some((format!("⚠ Error: {}", e), true));
                }
            }
        }
    }
}

impl eframe::App for GuiApp {
    fn update(&mut self, ctx: &egui::Context, _frame: &mut eframe::Frame) {
        Self::apply_theme(ctx);
        if let Ok(spec) = self.shared_spectrum.lock() {
            self.spectrum = spec.clone();
        }

        let is_recording = self.recording_flag.load(Ordering::Relaxed);
        let is_playing = self.playback_flag.load(Ordering::Relaxed);
        let is_running = self.audio_running.load(Ordering::Relaxed);
        let recorded_len = self.recorded_samples.lock().map(|v| v.len()).unwrap_or(0);
        let loaded_len = self
            .loaded_file_samples
            .lock()
            .map(|v| v.len())
            .unwrap_or(0);

        egui::TopBottomPanel::top("top_bar")
            .exact_height(64.0)
            .show(ctx, |ui| {
                ui.add_space(8.0);

                ui.horizontal(|ui| {
                    ui.heading(
                        egui::RichText::new("Granular Synth Interface")
                            .size(26.0)
                            .strong()
                            .color(egui::Color32::from_rgb(240, 245, 250)),
                    );

                    ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                        if ui.button(egui::RichText::new("❔").size(20.0)).clicked() {
                            self.show_help = !self.show_help;
                        }
                        let status = if is_running { "RUNNING" } else { "STOPPED" };

                        let color = if is_running {
                            egui::Color32::from_rgb(60, 200, 120)
                        } else {
                            egui::Color32::from_rgb(210, 80, 80)
                        };

                        egui::Frame::new()
                            .fill(egui::Color32::from_rgb(30, 36, 45))
                            .corner_radius(egui::CornerRadius::same(20))
                            .inner_margin(egui::Margin::symmetric(12, 6))
                            .show(ui, |ui| {
                                ui.label(
                                    egui::RichText::new(format!("Audio {}", status))
                                        .strong()
                                        .color(color),
                                );
                            });
                    });
                });
            });

        egui::SidePanel::left("control_panel")
            .resizable(false)
            .default_width(320.0)
            .frame(
                egui::Frame::new()
                    .fill(egui::Color32::from_rgb(20, 24, 31))
                    .inner_margin(egui::Margin::same(10)),
            )
            .show(ctx, |ui| {
                egui::ScrollArea::vertical()
                    .auto_shrink([false, false])
                    .show(ui, |ui| {
                        ui.add_space(4.0);

                        Self::section_card(ui, "Transport", |ui| {
                            ui.horizontal_wrapped(|ui| {
                                if Self::premium_button(
                                    ui,
                                    "Start",
                                    egui::Color32::from_rgb(38, 166, 106),
                                    [124.0, 40.0],
                                )
                                .clicked()
                                {
                                    self.audio_running.store(true, Ordering::Relaxed);
                                }

                                if Self::premium_button(
                                    ui,
                                    "Stop",
                                    egui::Color32::from_rgb(180, 68, 68),
                                    [124.0, 40.0],
                                )
                                .clicked()
                                {
                                    self.audio_running.store(false, Ordering::Relaxed);
                                }
                            });
                        });

                        ui.add_space(8.0);

                        Self::section_card(ui, "Source", |ui| {
                            let micro_selected = self.params.source_mode == AudioSourceMode::Micro;
                            let file_selected = self.params.source_mode == AudioSourceMode::File;

                            ui.horizontal_wrapped(|ui| {
                                if Self::premium_toggle_button(
                                    ui,
                                    "Micro",
                                    micro_selected,
                                    [118.0, 38.0],
                                )
                                .clicked()
                                {
                                    self.params.source_mode = AudioSourceMode::Micro;
                                    self.shared_source_mode
                                        .store(AudioSourceMode::Micro as u32, Ordering::Relaxed);
                                }

                                if Self::premium_toggle_button(
                                    ui,
                                    "File",
                                    file_selected,
                                    [118.0, 38.0],
                                )
                                .clicked()
                                {
                                    self.params.source_mode = AudioSourceMode::File;
                                    self.shared_source_mode
                                        .store(AudioSourceMode::File as u32, Ordering::Relaxed);
                                }
                            });

                            ui.add_space(6.0);

                            if Self::premium_button(
                                ui,
                                "Load Audio",
                                egui::Color32::from_rgb(70, 118, 220),
                                [132.0, 40.0],
                            )
                            .clicked()
                            {
                                if let Some(path) = rfd::FileDialog::new()
                                    .add_filter("Audio Files", &["wav", "mp3", "flac"])
                                    .pick_file()
                                {
                                    if let Ok(mut locked_path) = self.shared_file_path.lock() {
                                        *locked_path = path.display().to_string();
                                    }

                                    let current = self.load_trigger.load(Ordering::Relaxed);
                                    self.load_trigger
                                        .store(current.wrapping_add(1), Ordering::Relaxed);
                                }
                            }

                            ui.label(
                                egui::RichText::new(format!("Loaded samples: {}", loaded_len))
                                    .color(egui::Color32::from_rgb(180, 190, 205)),
                            );
                        });

                        ui.add_space(8.0);

                        Self::section_card(ui, "Recording", |ui| {
                            ui.horizontal_wrapped(|ui| {
                                if Self::premium_button(
                                    ui,
                                    "Start Rec",
                                    egui::Color32::from_rgb(214, 134, 48),
                                    [124.0, 40.0],
                                )
                                .clicked()
                                {
                                    self.recording_flag.store(true, Ordering::Relaxed);
                                    self.playback_flag.store(false, Ordering::Relaxed);
                                    self.playback_index.store(0, Ordering::Relaxed);
                                }

                                if Self::premium_button(
                                    ui,
                                    "Stop Rec",
                                    egui::Color32::from_rgb(123, 84, 196),
                                    [124.0, 40.0],
                                )
                                .clicked()
                                {
                                    self.recording_flag.store(false, Ordering::Relaxed);
                                }
                            });

                            ui.horizontal_wrapped(|ui| {
                                if Self::premium_button(
                                    ui,
                                    "Play Rec",
                                    egui::Color32::from_rgb(52, 156, 176),
                                    [124.0, 40.0],
                                )
                                .clicked()
                                {
                                    self.recording_flag.store(false, Ordering::Relaxed);
                                    self.playback_index.store(0, Ordering::Relaxed);
                                    self.playback_flag.store(true, Ordering::Relaxed);
                                }

                                if Self::premium_button(
                                    ui,
                                    "Clear Rec",
                                    egui::Color32::from_rgb(92, 100, 116),
                                    [124.0, 40.0],
                                )
                                .clicked()
                                {
                                    self.recording_flag.store(false, Ordering::Relaxed);
                                    self.playback_flag.store(false, Ordering::Relaxed);
                                    self.playback_index.store(0, Ordering::Relaxed);

                                    if let Ok(mut data) = self.recorded_samples.lock() {
                                        data.clear();
                                    }
                                    // Clear the resampled buffer to force rebuild on next Play Rec
                                    if let Ok(mut buf) = self.shared_playback_resampled.lock() {
                                        buf.clear();
                                    }
                                }
                            });

                            ui.add_space(6.0);


                            if Self::premium_button(
                                ui,
                                "💾  Save WAV",
                                egui::Color32::from_rgb(58, 128, 204),
                                [260.0, 40.0],
                            )
                            .clicked()
                            {
                                self.trigger_save();
                            }

                            if let Some((ref msg, is_error)) = self.save_status_msg {
                                ui.add_space(6.0);
                                let color = if is_error {
                                    egui::Color32::from_rgb(220, 80, 80)
                                } else {
                                    egui::Color32::from_rgb(80, 200, 120)
                                };
                                ui.label(egui::RichText::new(msg.clone()).color(color).size(13.0));
                            }

                            ui.add_space(6.0);

                            ui.label(format!(
                                "Recording: {}",
                                if is_recording { "ON" } else { "OFF" }
                            ));

                            ui.label(format!(
                                "Playback: {}",
                                if is_playing { "ON" } else { "OFF" }
                            ));

                            ui.label(format!("Recorded samples: {}", recorded_len));
                        });

                        ui.add_space(8.0);

                        Self::section_card(ui, "Granular Controls", |ui| {
                            let effect_text = if self.params.effect_on {
                                "Disable Effect"
                            } else {
                                "Enable Effect"
                            };

                            if Self::premium_button(
                                ui,
                                effect_text,
                                egui::Color32::from_rgb(126, 78, 214),
                                [170.0, 40.0],
                            )
                            .clicked()
                            {
                                self.params.effect_on = !self.params.effect_on;

                                let value = if self.params.effect_on {
                                    1.0f32
                                } else {
                                    0.0f32
                                };
                                self.shared_effect_on
                                    .store(value.to_bits(), Ordering::Relaxed);
                            }

                            ui.add_space(8.0);

                            ui.label("Grain size");

                            let size_slider = ui.add(
                                egui::Slider::new(&mut self.params.grain_size_ms, 5.0..=500.0)
                                    .suffix(" ms")
                                    .show_value(true),
                            );

                            if size_slider.changed() {
                                self.shared_size
                                    .store(self.params.grain_size_ms.to_bits(), Ordering::Relaxed);
                            }

                            ui.label("Density");

                            let density_slider = ui.add(
                                egui::Slider::new(&mut self.params.density, 2.0..=100.0)
                                    .suffix(" grains/s"),
                            );

                            if density_slider.changed() {
                                self.shared_density
                                    .store(self.params.density.to_bits(), Ordering::Relaxed);
                            }

                            ui.label("Pitch");

                            let pitch_slider = ui.add(
                                egui::Slider::new(&mut self.params.pitch, 0.25..=4.0)
                                    .logarithmic(true)
                                    .suffix("x"),
                            );

                            if pitch_slider.changed() {
                                self.shared_pitch
                                    .store(self.params.pitch.to_bits(), Ordering::Relaxed);
                            }

                            ui.label("Reverse Chance");

                            let reverse_slider = ui.add(
                                egui::Slider::new(&mut self.params.reverse_prob, 0.0..=1.0)
                                    .custom_formatter(|n, _| format!("{:.0}%", n * 100.0)),
                            );

                            if reverse_slider.changed() {
                                self.shared_reverse
                                    .store(self.params.reverse_prob.to_bits(), Ordering::Relaxed);
                            }
                        });
                        ui.add_space(8.0);

                        Self::section_card(ui, "Status", |ui| {
                            ui.label(format!(
                                "Source: {}",
                                match self.params.source_mode {
                                    AudioSourceMode::Micro => "Micro",
                                    AudioSourceMode::File => "File",
                                }
                            ));

                            ui.label(format!(
                                "Effect: {}",
                                if self.params.effect_on { "ON" } else { "OFF" }
                            ));

                            ui.label(format!("Size: {:.1} ms", self.params.grain_size_ms));
                            ui.label(format!("Density: {:.1} gps", self.params.density));
                            ui.label(format!("Pitch: {:.2}x", self.params.pitch));
                            ui.label(format!("Reverse: {:.0}%", self.params.reverse_prob * 100.0));
                        });
                        ui.add_space(10.0);
                    });
            });

        egui::CentralPanel::default()
            .frame(
                egui::Frame::new()
                    .fill(egui::Color32::from_rgb(16, 20, 26))
                    .inner_margin(egui::Margin::same(16)),
            )
            .show(ctx, |ui| {
                egui::Frame::new()
                    .fill(egui::Color32::from_rgb(26, 31, 40))
                    .stroke(egui::Stroke::new(1.0, egui::Color32::from_rgb(60, 72, 88)))
                    .corner_radius(egui::CornerRadius::same(16))
                    .inner_margin(egui::Margin::same(16))
                    .show(ui, |ui| {
                        ui.horizontal(|ui| {
                            ui.heading(
                                egui::RichText::new("Spectrum Analyzer").size(24.0).strong(),
                            );

                            ui.label(
                                egui::RichText::new("Real-time visual feedback")
                                    .color(egui::Color32::from_rgb(170, 180, 195)),
                            );
                        });

                        ui.add_space(12.0);
                        if let Some(frame) = &self.spectrum {
                            let n_bins = frame.magnitudes.len();
                            let fft_size = n_bins * 2;
                            let window_ms = (fft_size as f32 / frame.sample_rate as f32) * 1000.0;
                            let df = frame.sample_rate as f32 / fft_size as f32;

                            ui.label(
                                egui::RichText::new(format!(
                                     "FFT: {} samples | window: {:.1} ms | resolution: {:.1} Hz/bin | sample rate: {} Hz",
                                    fft_size,
                                    window_ms,
                                    df,
                                    frame.sample_rate
                                 ))
                                .color(egui::Color32::from_rgb(180, 190, 205)),
                            );

                            ui.label(
                                egui::RichText::new(format!(
                                    "This plot shows approximately the last {:.1} ms of the analyzed signal.",
                                    window_ms
                                 ))
                                .color(egui::Color32::from_rgb(150, 160, 175)),
                            );
                        } else {
                            ui.label(
                                egui::RichText::new("No FFT frame available yet.")
                                    .color(egui::Color32::from_rgb(150, 160, 175)),
                            );
                        }

                        ui.add_space(8.0);

                        let (freqs, mags) = match self.spectrum {
                            Some(ref frame) if !frame.magnitudes.is_empty() => {
                                let n = frame.magnitudes.len();
                                let df = frame.sample_rate as f64 / (2.0 * n as f64);
                                let mut f = Vec::with_capacity(n);
                                let mut m = Vec::with_capacity(n);

                                for (i, &mag) in frame.magnitudes.iter().enumerate() {
                                    f.push(i as f64 * df);
                                    m.push(mag as f64);
                                }

                                (f, m)
                            }

                            _ => {
                                let n = 256;
                                let mut f = Vec::with_capacity(n);
                                let mut m = Vec::with_capacity(n);

                                for i in 0..n {
                                    let freq = i as f64;
                                    let base = (freq / 20.0).sin().abs() * 0.3;
                                    let formant_center = 40.0 * self.params.pitch as f64;
                                    let formant =
                                        (-((freq - formant_center).powi(2)) / 400.0).exp() * 0.8;
                                    let amp = base + formant;
                                    f.push(freq);
                                    m.push(amp);
                                }

                                (f, m)
                            }
                        };

                        let points: Vec<[f64; 2]> = freqs
                            .into_iter()
                            .zip(mags.into_iter())
                            .map(|(x, y)| [x, y])
                            .collect();

                        let line = Line::new("Magnitude", PlotPoints::from_iter(points))
                            .color(egui::Color32::from_rgb(90, 170, 255))
                            .width(2.5);

                        ui.vertical_centered(|ui| {
                            ui.label(
                                egui::RichText::new("Magnitude (dB)")
                                    .color(egui::Color32::from_rgb(185, 195, 210))
                                    .strong(),
                            );
                        });

                        Plot::new("spectrum_plot")
                            .allow_scroll(false)
                            .allow_zoom(true)
                            .allow_drag(false)
                            .height(ui.available_height() - 40.0)
                            .width(ui.available_width())
                            .show_background(true)
                            .show(ui, |plot_ui| {
                                plot_ui.line(line);
                            });

                        ui.vertical_centered(|ui| {
                            ui.label(
                                egui::RichText::new("Frequency (Hz)")
                                    .color(egui::Color32::from_rgb(185, 195, 210))
                                    .strong(),
                            );
                        });
                    });
            });
        // --- THE HELP WINDOW ---
        if self.show_help {
            egui::Window::new("📖 User Guide")
                .collapsible(false)
                .resizable(true)
                .default_width(400.0)
                .show(ctx, |ui| {
                    ui.heading("Fast Workflow");
                    ui.label("1. Choose your source (WAV, MP3 or FLAC file, or Microphone).");
                    ui.label("2. Start playback (Start or Play Rec).");
                    ui.label("3. Click on 'Enable Effect' to activate granulation.");
                    ui.label("4. When you are happy with the sound, click on 'Save WAV' to export it to your Downloads folder.");

                    ui.separator();

                    ui.heading("Mode Micro (Looper)");
                    ui.label("Plug in headphones! Record your voice with 'Start Rec', then click 'Play Rec' to loop it and edit it live.");

                    ui.separator();

                    if ui.button("Close").clicked() {
                        self.show_help = false;
                    }
                });
        }
        ctx.request_repaint();
    }
}

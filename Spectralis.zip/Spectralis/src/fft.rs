#![allow(dead_code)]
use std::f64::consts::PI;
use std::ops::{Add, Mul, Sub};

// ═══════════════════════════════════════════════════════════════════════════
//  COMPLEX NUMBERS
// ═══════════════════════════════════════════════════════════════════════════

#[derive(Debug, Copy, Clone)]
pub struct Complex {
    pub re: f64,
    pub im: f64,
}

impl Complex {
    pub fn new(re: f64, im: f64) -> Self {
        Complex { re, im }
    }

    pub fn from_polar(theta: f64) -> Self {
        Complex::new(theta.cos(), theta.sin())
    }

    pub fn magnitude(&self) -> f64 {
        (self.re * self.re + self.im * self.im).sqrt()
    }

    pub fn conjugate(&self) -> Self {
        Complex::new(self.re, -self.im)
    }

    pub fn scale(&self, factor: f64) -> Self {
        Complex::new(self.re * factor, self.im * factor)
    }
}

impl Add for Complex {
    type Output = Self;
    fn add(self, other: Self) -> Self {
        Complex::new(self.re + other.re, self.im + other.im)
    }
}

impl Sub for Complex {
    type Output = Self;
    fn sub(self, other: Self) -> Self {
        Complex::new(self.re - other.re, self.im - other.im)
    }
}

impl Mul for Complex {
    type Output = Self;
    fn mul(self, other: Self) -> Self {
        Complex::new(
            self.re * other.re - self.im * other.im,
            self.re * other.im + self.im * other.re,
        )
    }
}

// ═══════════════════════════════════════════════════════════════════════════
//  HANN WINDOW
// ═══════════════════════════════════════════════════════════════════════════

pub fn apply_hann_window(buffer: &mut [Complex]) {
    let n = buffer.len();
    if n <= 1 {
        return;
    }
    let n_minus_1 = (n - 1) as f64;
    for (i, val) in buffer.iter_mut().enumerate() {
        let window = 0.5 * (1.0 - (2.0 * PI * i as f64 / n_minus_1).cos());
        val.re *= window;
        val.im *= window;
    }
}

// ═══════════════════════════════════════════════════════════════════════════
//  BIT-REVERSAL PERMUTATION
// ═══════════════════════════════════════════════════════════════════════════

fn bit_reverse_permutation(buffer: &mut [Complex]) {
    let n = buffer.len();
    let mut j = 0usize;

    for i in 1..n {
        let mut bit = n >> 1;
        while j & bit != 0 {
            j ^= bit;
            bit >>= 1;
        }
        j ^= bit;

        if i < j {
            buffer.swap(i, j);
        }
    }
}

// ═══════════════════════════════════════════════════════════════════════════
//  FFT COOLEY-TUKEY ITERATIVE IN-PLACE
// ═══════════════════════════════════════════════════════════════════════════

pub fn fft(buffer: &mut [Complex]) {
    let n = buffer.len();

    if n <= 1 {
        return;
    }

    assert!(
        n.is_power_of_two(),
        "Buffer size must be a power of 2 (got: {})",
        n
    );

    bit_reverse_permutation(buffer);

    let mut size = 2;
    while size <= n {
        let half = size / 2;
        let angle_step = -2.0 * PI / size as f64;

        let mut start = 0;
        while start < n {
            let mut twiddle = Complex::new(1.0, 0.0);
            let w_step = Complex::from_polar(angle_step);

            for k in 0..half {
                let i_even = start + k;
                let i_odd = start + k + half;

                let t = twiddle * buffer[i_odd];
                buffer[i_odd] = buffer[i_even] - t;
                buffer[i_even] = buffer[i_even] + t;

                twiddle = twiddle * w_step;
            }

            start += size;
        }

        size <<= 1;
    }
}

// ═══════════════════════════════════════════════════════════════════════════
//  INVERSE FFT (IFFT)
// ═══════════════════════════════════════════════════════════════════════════

pub fn ifft(buffer: &mut [Complex]) {
    let n = buffer.len();

    for val in buffer.iter_mut() {
        *val = val.conjugate();
    }

    fft(buffer);

    let inv_n = 1.0 / n as f64;
    for val in buffer.iter_mut() {
        *val = val.conjugate().scale(inv_n);
    }
}

// ═══════════════════════════════════════════════════════════════════════════
//  UTILITY FUNCTIONS
// ═══════════════════════════════════════════════════════════════════════════

pub fn samples_to_complex(samples: &[f32]) -> Vec<Complex> {
    samples
        .iter()
        .map(|&s| Complex::new(s as f64, 0.0))
        .collect()
}

pub fn compute_magnitudes(spectrum: &[Complex]) -> Vec<f32> {
    let half = spectrum.len() / 2;
    spectrum[..half]
        .iter()
        .map(|c| c.magnitude() as f32)
        .collect()
}

pub fn compute_magnitudes_db(spectrum: &[Complex]) -> Vec<f32> {
    let half = spectrum.len() / 2;
    let floor = 1e-6_f64;
    spectrum[..half]
        .iter()
        .map(|c| {
            let mag = c.magnitude().max(floor);
            (20.0 * mag.log10()) as f32
        })
        .collect()
}

pub fn zero_pad_to_power_of_two(buffer: &mut Vec<Complex>) {
    let n = buffer.len();
    if n == 0 {
        return;
    }
    if n.is_power_of_two() {
        return;
    }
    let target = n.next_power_of_two();
    buffer.resize(target, Complex::new(0.0, 0.0));
}

// ═══════════════════════════════════════════════════════════════════════════
//  UNIT TESTS
// ═══════════════════════════════════════════════════════════════════════════

#[cfg(test)]
mod tests {
    use super::*;
    use std::time::Instant;

    #[test]
    fn test_fft_sine_440hz() {
        let n = 1024;
        let sample_rate = 44100.0;
        let freq = 440.0;

        let mut buffer: Vec<Complex> = (0..n)
            .map(|i| {
                let t = i as f64 / sample_rate;
                Complex::new((2.0 * PI * freq * t).sin(), 0.0)
            })
            .collect();

        fft(&mut buffer);

        let magnitudes = compute_magnitudes(&buffer);

        let (max_bin, _max_mag) = magnitudes
            .iter()
            .enumerate()
            .max_by(|(_, a), (_, b)| a.partial_cmp(b).unwrap())
            .unwrap();

        let expected_bin = (freq * n as f64 / sample_rate).round() as usize;

        assert!(
            (max_bin as i32 - expected_bin as i32).unsigned_abs() <= 1,
            "FFT peak should be at bin {} (440 Hz), but found at bin {}",
            expected_bin,
            max_bin
        );
    }

    #[test]
    fn test_fft_ifft_roundtrip() {
        let n = 256;
        let sample_rate = 44100.0;

        let original: Vec<Complex> = (0..n)
            .map(|i| {
                let t = i as f64 / sample_rate;
                let val = (2.0 * PI * 440.0 * t).sin() + 0.5 * (2.0 * PI * 1000.0 * t).sin();
                Complex::new(val, 0.0)
            })
            .collect();

        let mut buffer = original.clone();

        fft(&mut buffer);
        ifft(&mut buffer);

        for (i, (orig, recon)) in original.iter().zip(buffer.iter()).enumerate() {
            assert!(
                (orig.re - recon.re).abs() < 1e-10,
                "Sample {}: original = {}, reconstructed = {} (error = {})",
                i,
                orig.re,
                recon.re,
                (orig.re - recon.re).abs()
            );
        }
    }

    #[test]
    fn test_fft_performance_4096() {
        let n = 4096;
        let sample_rate = 44100.0;

        let mut buffer: Vec<Complex> = (0..n)
            .map(|i| {
                let t = i as f64 / sample_rate;
                Complex::new((2.0 * PI * 440.0 * t).sin(), 0.0)
            })
            .collect();

        let start = Instant::now();
        fft(&mut buffer);
        let elapsed = start.elapsed();

        println!(
            "FFT of {} samples completed in {:.3}ms",
            n,
            elapsed.as_secs_f64() * 1000.0
        );

        assert!(
            elapsed.as_millis() < 20,
            "FFT of {} points took {}ms (limit: 20ms)",
            n,
            elapsed.as_millis()
        );
    }

    #[test]
    fn test_hann_window() {
        let n = 256;
        let mut buffer: Vec<Complex> = vec![Complex::new(1.0, 0.0); n];

        apply_hann_window(&mut buffer);

        assert!(
            buffer[0].re.abs() < 1e-10,
            "First windowed sample should be ~0, got: {}",
            buffer[0].re
        );
        assert!(
            buffer[n - 1].re.abs() < 1e-10,
            "Last windowed sample should be ~0, got: {}",
            buffer[n - 1].re
        );

        let center = n / 2;
        assert!(
            (buffer[center].re - 1.0).abs() < 0.01,
            "Center windowed sample should be ~1, got: {}",
            buffer[center].re
        );
    }

    #[test]
    fn test_zero_padding() {
        let mut buffer: Vec<Complex> = vec![Complex::new(1.0, 0.0); 100];
        zero_pad_to_power_of_two(&mut buffer);

        assert_eq!(buffer.len(), 128, "100 should be padded to 128");
        assert!(
            buffer[99].re == 1.0,
            "Original data must be preserved"
        );
        assert!(buffer[100].re == 0.0, "Padding must be zeros");
    }

    #[test]
    fn test_samples_to_complex() {
        let samples = vec![1.0f32, -0.5, 0.0, 0.25];
        let complex = samples_to_complex(&samples);

        assert_eq!(complex.len(), 4);
        assert!((complex[0].re - 1.0).abs() < 1e-10);
        assert!((complex[1].re - (-0.5)).abs() < 1e-10);
        assert!(complex[0].im.abs() < 1e-10);
    }

    #[test]
    fn test_magnitudes_db() {
        let n = 64;
        let mut buffer: Vec<Complex> = vec![Complex::new(1.0, 0.0); n];
        fft(&mut buffer);

        let db = compute_magnitudes_db(&buffer);

        assert!(
            db[0] > 30.0,
            "DC bin should have high magnitude in dB, got: {} dB",
            db[0]
        );

        for (i, &val) in db.iter().enumerate().skip(1) {
            assert!(
                val < 0.0,
                "Bin {} should be negative in dB for a DC signal, got: {} dB",
                i,
                val
            );
        }
    }
}
